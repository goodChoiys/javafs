package EndGame.TeamPj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamPjApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamPjApplication.class, args);
	}

}
