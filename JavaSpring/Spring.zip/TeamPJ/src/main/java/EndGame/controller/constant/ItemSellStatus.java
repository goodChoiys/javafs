package EndGame.controller.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
