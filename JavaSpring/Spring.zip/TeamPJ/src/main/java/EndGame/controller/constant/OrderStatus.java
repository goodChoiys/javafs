package EndGame.controller.constant;

public enum OrderStatus {

    ORDER, CANCEL
}
