package EndGame.controller.constant;

public enum Role {
    USER, ADMIN
}
