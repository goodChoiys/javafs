package thymeleaf.thymeleafex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafexApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymeleafexApplication.class, args);
	}

}
