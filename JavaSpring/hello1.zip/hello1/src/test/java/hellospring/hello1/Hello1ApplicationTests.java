package hellospring.hello1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hello1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
