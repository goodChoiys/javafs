package hellospring.hello1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hello1Application {

	public static void main(String[] args) {
		SpringApplication.run(Hello1Application.class, args);
	}

}
