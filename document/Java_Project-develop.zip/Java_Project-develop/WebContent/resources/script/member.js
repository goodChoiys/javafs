function loginCheck(){
	
	if(document.frm.userid.value.length == 0){
		alert("아이디를 입력하세요.");
		document.frm.userid.focus();
		
		return false;
	}
	
	if(document.frm.pwd.value == ""){
		alert("패스워드는 반드시 입력해야 합니다.");
		document.frm.pwd.focus();
		
		return false;
	}
	
	return true;
}

function idCheck(){
	
	if(document.frm.userid.value == ""){
		alert("아이디를 입력해 주세요.");
		document.frm.userid.focus();
		
		return;
	}
	
	var url="idCheck.do?userid="+document.frm.userid.value;
	window.open(url,"_blank_1","toolbar=no,menubar=no,"+"scrollbars=yes,resizable=no,width=450,height=200");
}

function idok(userid){
	opener.frm.userid.value=document.frm.userid.value;
	opener.frm.reid.value=document.frm.userid.value;
	self.close();
}

function joinCheck(){
	
	if(document.frm.name.value.length == 0){
		alert("이름을 써 주세요.");
		document.frm.name.focus();
		
		return false;
	}
	
	if(document.frm.userid.value.length == 0){
		alert("아이디 써 주세요.");
		document.frm.userid.focus();
		
		return false;
	}
	
	if(document.frm.userid.value.length < 4){
		alert("아이디 4글자 이상이어야 합니다.");
		document.frm.userid.focus();
		
		return false;
	}
	
	if(document.frm.pwd.value == ""){
		alert("암호는 반드시 입력해야합니다.");
		document.frm.pwd.focus();
		
		return false;
	}
	
	if(document.frm.pwd.value != document.frm.pwd_check.value){
		alert("암호가 일치하지 않습니다.")
		document.frm.pwd.focus();
		
		return false;
	}

	if(document.frm.reid.value.length == 0){
		alert("중복 체크를 하지 않았습니다.");
		document.frm.userid.focus();
		
		return false;
	}

	return true;
	
}
  
function onSubmit() {
	document.frm.addEventListener('submit', function(event) {
		if (document.frm.checkValidity() === false) {
			event.preventDefault();
			event.stopPropagation();
		} else
			document.frm.submit();
		document.frm.classList.add('was-validated');
	}, false);
}

function onModify() {
	if (confirm("정말 수정하시겠습니까?") == true) {
		document.form.addEventListener('submit', function(event) {
			if (document.form.checkValidity() === false) {
				event.preventDefault();
				event.stopPropagation();
			} else
				document.form.submit();
			document.form.classList.add('was-validated');
		}, false);
	} else {

	}
}

function onDelete() {
	if (confirm("정말 탈퇴하시겠습니까?") == true) {

	} else {

	}
}

function onCheckId() {    	
	/*
  	if(document.frm.id.value == ""){
		alert("아이디를 입력해 주세요.");
		document.frm.id.focus();
		return;
  	}
  	*/
//var url="idCheck.do?userid="+document.frm.userid.value;
//window.open(url,"_blank_1","toolbar=no,menubar=no,"+"scrollbars=yes,resizable=no,width=450,height=200");
	
	return true;
  }	
  
function onCheckNickName() {    	
  	if(document.frm.nickName.value == ""){
		alert("별명을 입력해 주세요.");
		document.frm.nickName.focus();
		return;
	}

//var url="idCheck.do?userid="+document.frm.userid.value;
//window.open(url,"_blank_1","toolbar=no,menubar=no,"+"scrollbars=yes,resizable=no,width=450,height=200");
  }