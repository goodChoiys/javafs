public class Ex4_7_3 {
    public static void main(String[] args) {
        for(int i = 1; i <= 3; i++){
            System.out.printf("HELLOW");
        }
    }
}
