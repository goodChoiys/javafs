public class Ex4_7_1 {
    public static void main(String[] args) {
        int num = 0;
        for(int i = 1; i <= 100; i++){
          
           
            System.out.println(i);
        }
    }
}
// 