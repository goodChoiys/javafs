package com.shop.controller.constant;

public enum OrderStatus {

    ORDER, CANCEL
}
