package com.shop.controller.constant;

public enum Role {
    USER, ADMIN
}
