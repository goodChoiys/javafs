package com.shop.controller.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
